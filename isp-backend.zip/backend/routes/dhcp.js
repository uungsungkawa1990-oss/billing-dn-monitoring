'use strict';

const router = require('express').Router();
const c = require('../controllers/dhcp.controller');

router.get('/lease', c.leases);
router.post('/lease/make-static', c.makeStatic);
router.delete('/lease', c.removeLease);

module.exports = router;
