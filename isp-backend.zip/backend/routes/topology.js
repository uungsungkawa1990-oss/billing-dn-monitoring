'use strict';

const router = require('express').Router();
const c = require('../controllers/topology.controller');

router.get('/', c.list);
router.get('/tree', c.tree);
router.get('/:id', c.detail);
router.post('/', c.create);
router.put('/:id', c.update);
router.delete('/:id', c.remove);

module.exports = router;
