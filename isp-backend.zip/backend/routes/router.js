'use strict';

const router = require('express').Router();
const c = require('../controllers/router.controller');

router.get('/', c.list);
router.get('/:id', c.detail);
router.post('/', c.create);
router.put('/:id', c.update);
router.delete('/:id', c.remove);
router.post('/:id/disconnect', c.disconnect);

module.exports = router;
