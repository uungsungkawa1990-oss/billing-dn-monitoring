'use strict';

const router = require('express').Router();
const c = require('../controllers/hotspot.controller');

router.get('/active', c.active);
router.post('/active/disconnect', c.disconnectActive);

router.get('/user', c.users);
router.get('/user/detail', c.userDetail);
router.post('/user', c.createUser);
router.put('/user', c.updateUser);
router.delete('/user', c.deleteUser);

router.post('/enable', c.enable);
router.post('/disable', c.disable);

module.exports = router;
