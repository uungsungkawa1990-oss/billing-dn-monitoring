'use strict';

const router = require('express').Router();
const c = require('../controllers/traffic.controller');

router.get('/once', c.once);
router.get('/stream', c.stream);
router.get('/torch', c.torch);
router.get('/ping', c.ping);

module.exports = router;
