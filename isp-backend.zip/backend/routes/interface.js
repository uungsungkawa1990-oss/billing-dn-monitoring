'use strict';

const router = require('express').Router();
const c = require('../controllers/interface.controller');

router.get('/', c.list);
router.get('/detail', c.detail);
router.post('/enable', c.enable);
router.post('/disable', c.disable);

module.exports = router;
