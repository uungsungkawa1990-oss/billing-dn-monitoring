'use strict';

const router = require('express').Router();
const c = require('../controllers/pppoe.controller');

router.get('/active', c.active);
router.post('/active/disconnect', c.disconnectActive);

router.get('/secret', c.secrets);
router.get('/secret/detail', c.secretDetail);
router.post('/secret', c.createSecret);
router.put('/secret', c.updateSecret);
router.delete('/secret', c.deleteSecret);

router.post('/enable', c.enable);
router.post('/disable', c.disable);
router.post('/isolir', c.isolir);
router.post('/activate', c.activate);

module.exports = router;
