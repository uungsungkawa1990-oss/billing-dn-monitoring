'use strict';

const router = require('express').Router();
const c = require('../controllers/firewall.controller');

router.get('/address-list', c.addressList);
router.post('/address-list', c.addAddress);
router.delete('/address-list', c.removeAddress);

module.exports = router;
