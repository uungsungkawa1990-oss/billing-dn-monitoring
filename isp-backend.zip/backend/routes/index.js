'use strict';

const router = require('express').Router();
const { authenticate } = require('../middleware/auth');
const monitoringController = require('../controllers/monitoring.controller');

const authRoutes = require('./auth');
const systemRoutes = require('./system');
const pppoeRoutes = require('./pppoe');
const hotspotRoutes = require('./hotspot');
const queueRoutes = require('./queue');
const interfaceRoutes = require('./interface');
const trafficRoutes = require('./traffic');
const customerRoutes = require('./customer');
const monitoringRoutes = require('./monitoring');
const firewallRoutes = require('./firewall');
const dhcpRoutes = require('./dhcp');
const routerRoutes = require('./router');
const topologyRoutes = require('./topology');

// Publik (tanpa auth) - untuk load balancer / uptime monitor
router.get('/health', monitoringController.health);
router.use('/auth', authRoutes);

// Semua route di bawah ini wajib autentikasi (JWT Bearer / x-api-key)
router.use('/system', authenticate, systemRoutes);
router.use('/pppoe', authenticate, pppoeRoutes);
router.use('/hotspot', authenticate, hotspotRoutes);
router.use('/queue', authenticate, queueRoutes);
router.use('/interface', authenticate, interfaceRoutes);
router.use('/traffic', authenticate, trafficRoutes);
router.use('/customer', authenticate, customerRoutes);
router.use('/monitoring', authenticate, monitoringRoutes);
router.use('/firewall', authenticate, firewallRoutes);
router.use('/dhcp', authenticate, dhcpRoutes);
router.use('/router', authenticate, routerRoutes);
router.use('/topology', authenticate, topologyRoutes);

module.exports = router;
