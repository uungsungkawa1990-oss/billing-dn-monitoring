'use strict';

const router = require('express').Router();
const c = require('../controllers/customer.controller');

router.get('/', c.list);
router.get('/:id', c.detail);
router.post('/', c.create);
router.put('/:id', c.update);
router.delete('/:id', c.remove);

router.post('/:id/enable', c.enable);
router.post('/:id/disable', c.disable);
router.post('/:id/isolir', c.isolir);
router.post('/:id/activate', c.activate);

module.exports = router;
