'use strict';

const router = require('express').Router();
const systemController = require('../controllers/system.controller');

router.post('/login', systemController.login);
router.get('/identity', systemController.identity);
router.get('/resource/cpu', systemController.resourceCpu);
router.get('/resource/memory', systemController.resourceMemory);
router.get('/resource/disk', systemController.resourceDisk);
router.get('/resource', systemController.resourceAll);
router.post('/reboot', systemController.reboot);
router.get('/pool-status', systemController.poolStatus);

module.exports = router;
