'use strict';

const router = require('express').Router();
const c = require('../controllers/queue.controller');

router.get('/simple', c.simpleList);
router.get('/simple/detail', c.simpleDetail);
router.post('/simple', c.simpleCreate);
router.put('/simple', c.simpleUpdate);
router.delete('/simple', c.simpleDelete);
router.post('/simple/isolir', c.simpleIsolir);
router.post('/simple/activate', c.simpleActivate);

router.get('/tree', c.treeList);
router.post('/tree', c.treeCreate);
router.put('/tree', c.treeUpdate);
router.delete('/tree', c.treeDelete);

module.exports = router;
