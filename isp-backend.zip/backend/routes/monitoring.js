'use strict';

const router = require('express').Router();
const c = require('../controllers/monitoring.controller');

router.get('/health', c.health);
router.get('/router-status', c.routerStatus);
router.get('/dashboard', c.dashboard);
router.get('/logs', c.logs);

module.exports = router;
