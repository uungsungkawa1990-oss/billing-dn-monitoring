'use strict';

const { createClient } = require('@supabase/supabase-js');
const logger = require('../utils/logger');

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  logger.error('SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY belum diset di .env');
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: {
    autoRefreshToken: false,
    persistSession: false
  },
  db: {
    schema: 'public'
  }
});

const TABLES = {
  ROUTERS: process.env.SB_TABLE_ROUTERS || 'routers',
  CUSTOMERS: process.env.SB_TABLE_CUSTOMERS || 'customers',
  NETWORK_NODES: process.env.SB_TABLE_NETWORK_NODES || 'network_nodes',
  AREAS: process.env.SB_TABLE_AREAS || 'areas',
  LOGS: process.env.SB_TABLE_LOGS || 'activity_logs'
};

module.exports = { supabase, TABLES };
