'use strict';

module.exports = {
  defaultPort: parseInt(process.env.MIKROTIK_DEFAULT_PORT || '8728', 10),
  defaultTlsPort: parseInt(process.env.MIKROTIK_DEFAULT_TLS_PORT || '8729', 10),
  useTls: (process.env.MIKROTIK_USE_TLS || 'false').toLowerCase() === 'true',
  timeout: parseInt(process.env.MIKROTIK_TIMEOUT || '10000', 10),
  reconnectInterval: parseInt(process.env.MIKROTIK_RECONNECT_INTERVAL || '5000', 10),
  maxReconnectAttempts: parseInt(process.env.MIKROTIK_MAX_RECONNECT_ATTEMPTS || '0', 10), // 0 = unlimited
  isolirAddressList: 'isolir-pelanggan',
  isolirQueueMaxLimit: '512k/512k',
  isolirProfile: 'isolir'
};
