'use strict';

const jwt = require('jsonwebtoken');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');

const JWT_SECRET = process.env.JWT_SECRET;
const STATIC_API_KEY = process.env.API_KEY;

const authenticate = asyncHandler(async (req, res, next) => {
  const apiKeyHeader = req.headers['x-api-key'];
  if (apiKeyHeader && STATIC_API_KEY && apiKeyHeader === STATIC_API_KEY) {
    req.auth = { type: 'api-key' };
    return next();
  }

  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    throw new ApiError(401, 'Token otorisasi tidak ditemukan');
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.auth = { type: 'jwt', user: decoded };
    return next();
  } catch (err) {
    throw new ApiError(401, 'Token tidak valid atau kadaluarsa');
  }
});

function signToken(payload) {
  return jwt.sign(payload, JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '12h'
  });
}

module.exports = { authenticate, signToken };
