# ISP Backend API

Backend REST API untuk manajemen jaringan ISP: MikroTik RouterOS v7 (multi-router, multi-area, multi-hub) dan topologi hybrid (MikroTik → Hub → Hub → Pelanggan, serta OLT → ODC → ODP → ONT). Database menggunakan Supabase (hanya sebagai penyimpanan data, tanpa perubahan struktur).

## Stack

- Node.js v22 (CommonJS)
- Express.js
- node-routeros (RouterOS API client)
- @supabase/supabase-js
- PM2 (process manager)
- Winston (logging + rotasi harian)

## Struktur Project

```
backend/
├── app.js
├── server.js
├── ecosystem.config.js
├── package.json
├── .env.example
├── config/
│   ├── database.js
│   └── mikrotik.js
├── middleware/
│   ├── auth.js
│   ├── logger.js
│   └── errorHandler.js
├── services/
│   ├── mikrotik.service.js
│   └── supabase.service.js
├── controllers/
├── routes/
├── utils/
└── logs/
```

## Autentikasi

Semua endpoint (kecuali `GET /api/v1/health` dan `POST /api/v1/auth/login`) wajib menyertakan salah satu:

- Header `x-api-key: <API_KEY>` (untuk komunikasi service-to-service, misal dari Cloudflare Pages/Frontend)
- Header `Authorization: Bearer <JWT>` (didapat dari `POST /api/v1/auth/login`)

```
POST /api/v1/auth/login
Body: { "username": "admin", "password": "***" }
```

## Konsep Multi-Router / Multi-Area / Multi-Hub

Hampir seluruh endpoint MikroTik mewajibkan parameter `router_id` (query, body, atau param), yang merujuk ke baris pada tabel `routers` di Supabase. Backend akan mengambil kredensial (host, port, username, password, tls) dari Supabase, lalu membuka/menggunakan kembali koneksi API MikroTik dari connection pool internal (auto reconnect jika putus).

Ini memungkinkan satu backend melayani banyak MikroTik sekaligus (multi router), yang dikelompokkan per area/hub sesuai kolom `area` dan `hub` pada tabel `routers`.

## Konsep Hybrid Network

Tabel `network_nodes` (nama dapat disesuaikan lewat `.env`) menyimpan topologi generik dengan kolom minimal: `id, name, type, parent_id, area`. Nilai `type` yang didukung secara konseptual: `mikrotik`, `hub`, `olt`, `odc`, `odp`, `ont`, `customer`. Endpoint `GET /api/v1/topology/tree` membangun pohon topologi secara rekursif dari `parent_id`, sehingga backend dapat merepresentasikan:

```
MikroTik → Hub → Hub → Hub → Pelanggan
OLT → ODC → ODP → ONT
```

secara bersamaan dalam satu struktur data, tanpa mengubah skema Supabase yang sudah ada (nama tabel/kolom dipetakan lewat variabel environment `SB_TABLE_*`).

## Environment Variables

Salin `.env.example` menjadi `.env` lalu sesuaikan seluruh nilai (kredensial Supabase, JWT secret, API key, mapping nama tabel, dsb).

## Daftar Endpoint (prefix default: `/api/v1`)

### Auth
- `POST /auth/login`

### System
- `POST /system/login?router_id=` — login/test koneksi ke MikroTik
- `GET /system/identity?router_id=`
- `GET /system/resource/cpu?router_id=`
- `GET /system/resource/memory?router_id=`
- `GET /system/resource/disk?router_id=`
- `GET /system/resource?router_id=`
- `POST /system/reboot` `{ router_id }`
- `GET /system/pool-status`

### Interface
- `GET /interface?router_id=`
- `GET /interface/detail?router_id=&name=`
- `POST /interface/enable` `{ router_id, name }`
- `POST /interface/disable` `{ router_id, name }`

### Traffic Realtime / Ping / Torch
- `GET /traffic/once?router_id=&interface=`
- `GET /traffic/stream?router_id=&interface=` (Server-Sent Events)
- `GET /traffic/torch?router_id=&interface=&duration=5000`
- `GET /traffic/ping?router_id=&address=&count=4`

### PPPoE
- `GET /pppoe/active?router_id=`
- `POST /pppoe/active/disconnect` `{ router_id, id }`
- `GET /pppoe/secret?router_id=`
- `GET /pppoe/secret/detail?router_id=&name=`
- `POST /pppoe/secret` `{ router_id, name, password, profile, ... }`
- `PUT /pppoe/secret` `{ router_id, name, ...fields }`
- `DELETE /pppoe/secret` `{ router_id, name }`
- `POST /pppoe/enable` `{ router_id, name }`
- `POST /pppoe/disable` `{ router_id, name }`
- `POST /pppoe/isolir` `{ router_id, name }`
- `POST /pppoe/activate` `{ router_id, name, profile }`

### Hotspot
- `GET /hotspot/active?router_id=`
- `POST /hotspot/active/disconnect` `{ router_id, id }`
- `GET /hotspot/user?router_id=`
- `GET /hotspot/user/detail?router_id=&name=`
- `POST /hotspot/user` `{ router_id, name, password, ... }`
- `PUT /hotspot/user` `{ router_id, name, ...fields }`
- `DELETE /hotspot/user` `{ router_id, name }`
- `POST /hotspot/enable` `{ router_id, name }`
- `POST /hotspot/disable` `{ router_id, name }`

### Queue Simple & Tree
- `GET /queue/simple?router_id=`
- `GET /queue/simple/detail?router_id=&name=`
- `POST /queue/simple` `{ router_id, name, target, max-limit }`
- `PUT /queue/simple` `{ router_id, name, ...fields }`
- `DELETE /queue/simple` `{ router_id, name }`
- `POST /queue/simple/isolir` `{ router_id, name }`
- `POST /queue/simple/activate` `{ router_id, name, max_limit }`
- `GET /queue/tree?router_id=`
- `POST /queue/tree` `{ router_id, name, parent, max-limit }`
- `PUT /queue/tree` `{ router_id, id, ...fields }`
- `DELETE /queue/tree` `{ router_id, id }`

### Firewall Address List
- `GET /firewall/address-list?router_id=&list=`
- `POST /firewall/address-list` `{ router_id, list, address, comment, timeout }`
- `DELETE /firewall/address-list` `{ router_id, list, address }`

### DHCP Lease
- `GET /dhcp/lease?router_id=`
- `POST /dhcp/lease/make-static` `{ router_id, id }`
- `DELETE /dhcp/lease` `{ router_id, id }`

### Customer (Supabase + aksi MikroTik terpadu)
- `GET /customer`
- `GET /customer/:id`
- `POST /customer`
- `PUT /customer/:id`
- `DELETE /customer/:id`
- `POST /customer/:id/enable`
- `POST /customer/:id/disable`
- `POST /customer/:id/isolir`
- `POST /customer/:id/activate`

### Router (CRUD data MikroTik multi-router)
- `GET /router`
- `GET /router/:id`
- `POST /router`
- `PUT /router/:id`
- `DELETE /router/:id`
- `POST /router/:id/disconnect`

### Topology (Hybrid Network)
- `GET /topology`
- `GET /topology/tree?root_id=`
- `GET /topology/:id`
- `POST /topology`
- `PUT /topology/:id`
- `DELETE /topology/:id`

### Monitoring
- `GET /health` (publik, tanpa auth)
- `GET /monitoring/router-status`
- `GET /monitoring/dashboard`
- `GET /monitoring/logs`

## Format Response Standar

Sukses:
```json
{
  "success": true,
  "message": "OK",
  "data": {},
  "timestamp": "2026-07-18T00:00:00.000Z"
}
```

Gagal:
```json
{
  "success": false,
  "message": "Pesan error",
  "errors": null,
  "timestamp": "2026-07-18T00:00:00.000Z"
}
```

## Deploy ke VPS Ubuntu 24.04 (Node.js v22 + PM2 + Nginx)

### 1. Persiapan VPS

```bash
sudo apt update && sudo apt upgrade -y
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs nginx git
node -v   # pastikan v22.x
npm -v
sudo npm install -g pm2
```

### 2. Clone / Upload Project

```bash
sudo mkdir -p /var/www/isp-backend
sudo chown -R $USER:$USER /var/www/isp-backend
cd /var/www/isp-backend
git clone <url-repo-anda> .
cd backend
```

### 3. Install Dependencies

```bash
npm install --omit=dev
```

### 4. Konfigurasi Environment

```bash
cp .env.example .env
nano .env
```

Isi semua variabel: `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `JWT_SECRET`, `API_KEY`, `ADMIN_USERNAME`, `ADMIN_PASSWORD`, `CORS_ORIGIN` (isi domain Cloudflare Pages Anda), dan mapping tabel Supabase (`SB_TABLE_*`) sesuai schema yang sudah ada.

### 5. Jalankan dengan PM2

```bash
pm2 start ecosystem.config.js
pm2 save
pm2 startup systemd
```//ikuti instruksi yang ditampilkan pm2 startup untuk enable auto-start saat reboot

Perintah operasional:
```bash
pm2 status
pm2 logs isp-backend
pm2 restart isp-backend
pm2 stop isp-backend
```

### 6. Konfigurasi Nginx sebagai Reverse Proxy

Buat file `/etc/nginx/sites-available/isp-backend`:

```nginx
server {
    listen 80;
    server_name api.domainanda.com;

    location / {
        proxy_pass http://127.0.0.1:4000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;

        # Wajib untuk endpoint SSE (traffic realtime)
        proxy_buffering off;
        proxy_read_timeout 3600s;
    }
}
```

Aktifkan:

```bash
sudo ln -s /etc/nginx/sites-available/isp-backend /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### 7. Pasang SSL (Let's Encrypt)

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d api.domainanda.com
```

### 8. Firewall (opsional, disarankan)

```bash
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

### 9. Update Frontend (Cloudflare Pages)

Arahkan base URL API di frontend ke `https://api.domainanda.com/api/v1`, dan kirim header `x-api-key` atau `Authorization: Bearer <JWT>` pada setiap request.

## Kebutuhan Konfigurasi MikroTik (RouterOS v7)

Pastikan setiap MikroTik yang dikelola:

1. API service aktif: `IP > Services > api` (port default 8728) atau `api-ssl` (8729) jika `MIKROTIK_USE_TLS=true`.
2. User dengan permission penuh (group `full` atau grup custom dengan policy `api, read, write, test, reboot`) didaftarkan sebagai kredensial di tabel `routers` pada Supabase.
3. Untuk fitur isolir PPPoE berbasis profile, siapkan PPP profile bernama sesuai `isolirProfile` di `config/mikrotik.js` (default: `isolir`) dengan rate-limit/pool tersendiri.
4. Untuk fitur isolir berbasis address-list, siapkan firewall rule yang mereferensikan address-list `isolir-pelanggan` (dapat diubah di `config/mikrotik.js`).

## Catatan Skema Supabase

Backend ini **tidak membuat maupun mengubah skema Supabase**. Backend hanya membaca/menulis ke tabel yang sudah ada melalui nama tabel yang dikonfigurasi di `.env` (`SB_TABLE_ROUTERS`, `SB_TABLE_CUSTOMERS`, `SB_TABLE_NETWORK_NODES`, `SB_TABLE_AREAS`, `SB_TABLE_LOGS`). Sesuaikan nilai-nilai ini dengan nama tabel yang sudah Anda miliki, dan pastikan kolom yang direferensikan pada `services/supabase.service.js` (misal `host`/`ip`, `username`/`user`, `password`, `area`, `hub`, `type`, `parent_id`, `status`, `connection_type`, `queue_name`, `profile`) tersedia atau disesuaikan.
