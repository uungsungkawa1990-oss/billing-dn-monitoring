'use strict';

const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/response');
const { requireFields } = require('../utils/validators');
const ApiError = require('../utils/ApiError');
const { signToken } = require('../middleware/auth');

exports.login = asyncHandler(async (req, res) => {
  requireFields(req.body, ['username', 'password']);
  const { username, password } = req.body;

  if (username !== process.env.ADMIN_USERNAME || password !== process.env.ADMIN_PASSWORD) {
    throw new ApiError(401, 'Username atau password salah');
  }

  const token = signToken({ username, role: 'admin' });
  return success(res, { token, expiresIn: process.env.JWT_EXPIRES_IN || '12h' }, 'Login berhasil');
});
