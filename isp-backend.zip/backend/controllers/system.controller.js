'use strict';

const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/response');
const resolveRouter = require('../utils/resolveRouter');
const mikrotikService = require('../services/mikrotik.service');
const supabaseService = require('../services/supabase.service');

exports.login = asyncHandler(async (req, res) => {
  const router = await resolveRouter(req);
  const result = await mikrotikService.testLogin(router);
  await supabaseService.logActivity({ action: 'mikrotik_login', router_id: router.id });
  return success(res, result, 'Login MikroTik berhasil');
});

exports.identity = asyncHandler(async (req, res) => {
  const router = await resolveRouter(req);
  const data = await mikrotikService.getIdentity(router);
  return success(res, data);
});

exports.resourceCpu = asyncHandler(async (req, res) => {
  const router = await resolveRouter(req);
  const data = await mikrotikService.getResourceCpu(router);
  return success(res, data);
});

exports.resourceMemory = asyncHandler(async (req, res) => {
  const router = await resolveRouter(req);
  const data = await mikrotikService.getResourceMemory(router);
  return success(res, data);
});

exports.resourceDisk = asyncHandler(async (req, res) => {
  const router = await resolveRouter(req);
  const data = await mikrotikService.getResourceDisk(router);
  return success(res, data);
});

exports.resourceAll = asyncHandler(async (req, res) => {
  const router = await resolveRouter(req);
  const data = await mikrotikService.getResourceAll(router);
  return success(res, data);
});

exports.reboot = asyncHandler(async (req, res) => {
  const router = await resolveRouter(req);
  const data = await mikrotikService.reboot(router);
  await supabaseService.logActivity({ action: 'mikrotik_reboot', router_id: router.id });
  return success(res, data, 'Perintah reboot terkirim');
});

exports.poolStatus = asyncHandler(async (req, res) => {
  const data = mikrotikService.status();
  return success(res, data);
});
