'use strict';

const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/response');
const { requireFields } = require('../utils/validators');
const resolveRouter = require('../utils/resolveRouter');
const mikrotikService = require('../services/mikrotik.service');
const supabaseService = require('../services/supabase.service');

// ---------- QUEUE SIMPLE ----------
exports.simpleList = asyncHandler(async (req, res) => {
  const router = await resolveRouter(req);
  const data = await mikrotikService.getQueueSimple(router);
  return success(res, data);
});

exports.simpleDetail = asyncHandler(async (req, res) => {
  requireFields(req.query, ['name']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.getQueueSimpleByName(router, req.query.name);
  return success(res, data);
});

exports.simpleCreate = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name', 'target', 'max-limit']);
  const router = await resolveRouter(req);
  const { router_id, ...payload } = req.body;
  const data = await mikrotikService.createQueueSimple(router, payload);
  await supabaseService.logActivity({ action: 'queue_simple_create', router_id: router.id, target: payload.name });
  return success(res, data, 'Queue simple berhasil dibuat', 201);
});

exports.simpleUpdate = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name']);
  const router = await resolveRouter(req);
  const { router_id, name, ...payload } = req.body;
  const data = await mikrotikService.updateQueueSimple(router, name, payload);
  return success(res, data, 'Queue simple berhasil diupdate');
});

exports.simpleDelete = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.deleteQueueSimple(router, req.body.name);
  await supabaseService.logActivity({ action: 'queue_simple_delete', router_id: router.id, target: req.body.name });
  return success(res, data, 'Queue simple berhasil dihapus');
});

exports.simpleIsolir = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.isolirCustomerQueue(router, req.body.name);
  await supabaseService.logActivity({ action: 'queue_simple_isolir', router_id: router.id, target: req.body.name });
  return success(res, data, 'Queue simple diisolir');
});

exports.simpleActivate = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.activateCustomerQueue(router, req.body.name, req.body.max_limit);
  await supabaseService.logActivity({ action: 'queue_simple_activate', router_id: router.id, target: req.body.name });
  return success(res, data, 'Queue simple diaktifkan kembali');
});

// ---------- QUEUE TREE ----------
exports.treeList = asyncHandler(async (req, res) => {
  const router = await resolveRouter(req);
  const data = await mikrotikService.getQueueTree(router);
  return success(res, data);
});

exports.treeCreate = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name', 'parent', 'max-limit']);
  const router = await resolveRouter(req);
  const { router_id, ...payload } = req.body;
  const data = await mikrotikService.createQueueTree(router, payload);
  await supabaseService.logActivity({ action: 'queue_tree_create', router_id: router.id, target: payload.name });
  return success(res, data, 'Queue tree berhasil dibuat', 201);
});

exports.treeUpdate = asyncHandler(async (req, res) => {
  requireFields(req.body, ['id']);
  const router = await resolveRouter(req);
  const { router_id, id, ...payload } = req.body;
  const data = await mikrotikService.updateQueueTree(router, id, payload);
  return success(res, data, 'Queue tree berhasil diupdate');
});

exports.treeDelete = asyncHandler(async (req, res) => {
  requireFields(req.body, ['id']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.deleteQueueTree(router, req.body.id);
  await supabaseService.logActivity({ action: 'queue_tree_delete', router_id: router.id, target: req.body.id });
  return success(res, data, 'Queue tree berhasil dihapus');
});
