'use strict';

const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/response');
const { requireFields } = require('../utils/validators');
const ApiError = require('../utils/ApiError');
const supabaseService = require('../services/supabase.service');
const mikrotikService = require('../services/mikrotik.service');

async function getRouterConfigForCustomer(customer) {
  if (!customer.router_id) {
    throw new ApiError(422, `Pelanggan ${customer.username || customer.id} tidak memiliki router_id`);
  }
  const row = await supabaseService.getRouterById(customer.router_id);
  return {
    id: row.id,
    name: row.name,
    host: row.host || row.ip,
    port: row.port ? Number(row.port) : undefined,
    user: row.username || row.user,
    password: row.password,
    tls: row.use_tls || row.tls || false
  };
}

exports.list = asyncHandler(async (req, res) => {
  const data = await supabaseService.getAllCustomers(req.query);
  return success(res, data);
});

exports.detail = asyncHandler(async (req, res) => {
  const data = await supabaseService.getCustomerById(req.params.id);
  return success(res, data);
});

exports.create = asyncHandler(async (req, res) => {
  requireFields(req.body, ['username', 'connection_type']);
  const data = await supabaseService.createCustomer(req.body);
  return success(res, data, 'Pelanggan berhasil ditambahkan', 201);
});

exports.update = asyncHandler(async (req, res) => {
  const data = await supabaseService.updateCustomer(req.params.id, req.body);
  return success(res, data, 'Pelanggan berhasil diupdate');
});

exports.remove = asyncHandler(async (req, res) => {
  const data = await supabaseService.deleteCustomer(req.params.id);
  return success(res, data, 'Pelanggan berhasil dihapus');
});

// ---------- ENABLE ----------
exports.enable = asyncHandler(async (req, res) => {
  const customer = await supabaseService.getCustomerById(req.params.id);
  const router = await getRouterConfigForCustomer(customer);

  let result;
  if (customer.connection_type === 'hotspot') {
    result = await mikrotikService.enableCustomerHotspot(router, customer.username);
  } else {
    result = await mikrotikService.enableCustomerPppoe(router, customer.username);
  }

  await supabaseService.updateCustomerStatus(customer.id, 'active');
  await supabaseService.logActivity({ action: 'customer_enable', router_id: router.id, target: customer.username });
  return success(res, { customer: customer.id, ...result }, 'Pelanggan berhasil diaktifkan');
});

// ---------- DISABLE ----------
exports.disable = asyncHandler(async (req, res) => {
  const customer = await supabaseService.getCustomerById(req.params.id);
  const router = await getRouterConfigForCustomer(customer);

  let result;
  if (customer.connection_type === 'hotspot') {
    result = await mikrotikService.disableCustomerHotspot(router, customer.username);
  } else {
    result = await mikrotikService.disableCustomerPppoe(router, customer.username);
  }

  await supabaseService.updateCustomerStatus(customer.id, 'disabled');
  await supabaseService.logActivity({ action: 'customer_disable', router_id: router.id, target: customer.username });
  return success(res, { customer: customer.id, ...result }, 'Pelanggan berhasil dinonaktifkan');
});

// ---------- ISOLIR ----------
exports.isolir = asyncHandler(async (req, res) => {
  const customer = await supabaseService.getCustomerById(req.params.id);
  const router = await getRouterConfigForCustomer(customer);

  let result;
  if (customer.connection_type === 'hotspot') {
    result = await mikrotikService.setHotspotUserDisabled(router, customer.username, true);
  } else if (customer.queue_name) {
    result = await mikrotikService.isolirCustomerQueue(router, customer.queue_name);
  } else {
    result = await mikrotikService.isolirCustomerPppoe(router, customer.username);
  }

  await supabaseService.updateCustomerStatus(customer.id, 'isolir');
  await supabaseService.logActivity({ action: 'customer_isolir', router_id: router.id, target: customer.username });
  return success(res, { customer: customer.id, ...result }, 'Pelanggan berhasil diisolir (menunggak)');
});

// ---------- ACTIVATE (kembali normal setelah isolir) ----------
exports.activate = asyncHandler(async (req, res) => {
  const customer = await supabaseService.getCustomerById(req.params.id);
  const router = await getRouterConfigForCustomer(customer);

  let result;
  if (customer.connection_type === 'hotspot') {
    result = await mikrotikService.enableCustomerHotspot(router, customer.username);
  } else if (customer.queue_name) {
    result = await mikrotikService.activateCustomerQueue(router, customer.queue_name, customer.max_limit);
  } else {
    result = await mikrotikService.activateCustomerPppoe(router, customer.username, customer.profile);
  }

  await supabaseService.updateCustomerStatus(customer.id, 'active');
  await supabaseService.logActivity({ action: 'customer_activate', router_id: router.id, target: customer.username });
  return success(res, { customer: customer.id, ...result }, 'Pelanggan berhasil diaktifkan kembali');
});
