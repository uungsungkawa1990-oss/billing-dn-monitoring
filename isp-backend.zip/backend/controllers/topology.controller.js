'use strict';

const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/response');
const { requireFields } = require('../utils/validators');
const supabaseService = require('../services/supabase.service');

exports.list = asyncHandler(async (req, res) => {
  const data = await supabaseService.getAllNodes(req.query);
  return success(res, data);
});

exports.detail = asyncHandler(async (req, res) => {
  const data = await supabaseService.getNodeById(req.params.id);
  return success(res, data);
});

exports.tree = asyncHandler(async (req, res) => {
  const data = await supabaseService.buildTopologyTree(req.query.root_id || null);
  return success(res, data);
});

exports.create = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name', 'type']);
  const data = await supabaseService.createNode(req.body);
  return success(res, data, 'Node topologi berhasil ditambahkan', 201);
});

exports.update = asyncHandler(async (req, res) => {
  const data = await supabaseService.updateNode(req.params.id, req.body);
  return success(res, data, 'Node topologi berhasil diupdate');
});

exports.remove = asyncHandler(async (req, res) => {
  const data = await supabaseService.deleteNode(req.params.id);
  return success(res, data, 'Node topologi berhasil dihapus');
});
