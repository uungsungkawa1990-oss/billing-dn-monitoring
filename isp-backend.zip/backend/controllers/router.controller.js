'use strict';

const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/response');
const { requireFields } = require('../utils/validators');
const supabaseService = require('../services/supabase.service');
const mikrotikService = require('../services/mikrotik.service');

exports.list = asyncHandler(async (req, res) => {
  const data = await supabaseService.getAllRouters(req.query);
  return success(res, data);
});

exports.detail = asyncHandler(async (req, res) => {
  const data = await supabaseService.getRouterById(req.params.id);
  return success(res, data);
});

exports.create = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name', 'host', 'username', 'password']);
  const data = await supabaseService.createRouter(req.body);
  return success(res, data, 'Router berhasil ditambahkan', 201);
});

exports.update = asyncHandler(async (req, res) => {
  const data = await supabaseService.updateRouter(req.params.id, req.body);
  return success(res, data, 'Router berhasil diupdate');
});

exports.remove = asyncHandler(async (req, res) => {
  mikrotikService.disconnect(req.params.id);
  const data = await supabaseService.deleteRouter(req.params.id);
  return success(res, data, 'Router berhasil dihapus');
});

exports.disconnect = asyncHandler(async (req, res) => {
  mikrotikService.disconnect(req.params.id);
  return success(res, { disconnected: true }, 'Koneksi router diputus');
});
