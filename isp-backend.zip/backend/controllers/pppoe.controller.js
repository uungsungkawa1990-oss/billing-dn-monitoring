'use strict';

const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/response');
const { requireFields } = require('../utils/validators');
const resolveRouter = require('../utils/resolveRouter');
const mikrotikService = require('../services/mikrotik.service');
const supabaseService = require('../services/supabase.service');

// ---------- PPPoE ACTIVE ----------
exports.active = asyncHandler(async (req, res) => {
  const router = await resolveRouter(req);
  const data = await mikrotikService.getPppoeActive(router);
  return success(res, data);
});

exports.disconnectActive = asyncHandler(async (req, res) => {
  requireFields(req.body, ['id']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.disconnectPppoeActive(router, req.body.id);
  return success(res, data, 'Sesi PPPoE diputus');
});

// ---------- PPP SECRET ----------
exports.secrets = asyncHandler(async (req, res) => {
  const router = await resolveRouter(req);
  const data = await mikrotikService.getPppSecrets(router);
  return success(res, data);
});

exports.secretDetail = asyncHandler(async (req, res) => {
  requireFields(req.query, ['name']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.getPppSecretByName(router, req.query.name);
  return success(res, data);
});

exports.createSecret = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name', 'password', 'profile']);
  const router = await resolveRouter(req);
  const { router_id, ...payload } = req.body;
  const data = await mikrotikService.createPppSecret(router, payload);
  await supabaseService.logActivity({ action: 'ppp_secret_create', router_id: router.id, target: payload.name });
  return success(res, data, 'PPP secret berhasil dibuat', 201);
});

exports.updateSecret = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name']);
  const router = await resolveRouter(req);
  const { router_id, name, ...payload } = req.body;
  const data = await mikrotikService.updatePppSecret(router, name, payload);
  return success(res, data, 'PPP secret berhasil diupdate');
});

exports.deleteSecret = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.deletePppSecret(router, req.body.name);
  await supabaseService.logActivity({ action: 'ppp_secret_delete', router_id: router.id, target: req.body.name });
  return success(res, data, 'PPP secret berhasil dihapus');
});

// ---------- ENABLE / DISABLE / ISOLIR / ACTIVATE ----------
exports.enable = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.enableCustomerPppoe(router, req.body.name);
  await supabaseService.logActivity({ action: 'pppoe_enable', router_id: router.id, target: req.body.name });
  return success(res, data, 'Pelanggan PPPoE diaktifkan');
});

exports.disable = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.disableCustomerPppoe(router, req.body.name);
  await supabaseService.logActivity({ action: 'pppoe_disable', router_id: router.id, target: req.body.name });
  return success(res, data, 'Pelanggan PPPoE dinonaktifkan');
});

exports.isolir = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.isolirCustomerPppoe(router, req.body.name);
  await supabaseService.logActivity({ action: 'pppoe_isolir', router_id: router.id, target: req.body.name });
  return success(res, data, 'Pelanggan PPPoE diisolir');
});

exports.activate = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.activateCustomerPppoe(router, req.body.name, req.body.profile);
  await supabaseService.logActivity({ action: 'pppoe_activate', router_id: router.id, target: req.body.name });
  return success(res, data, 'Pelanggan PPPoE diaktifkan kembali');
});
