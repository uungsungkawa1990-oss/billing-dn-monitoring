'use strict';

const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/response');
const { requireQuery } = require('../utils/validators');
const resolveRouter = require('../utils/resolveRouter');
const mikrotikService = require('../services/mikrotik.service');

exports.list = asyncHandler(async (req, res) => {
  const router = await resolveRouter(req);
  const data = await mikrotikService.getInterfaces(router);
  return success(res, data);
});

exports.detail = asyncHandler(async (req, res) => {
  requireQuery(req.query, ['name']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.getInterfaceByName(router, req.query.name);
  return success(res, data);
});

exports.enable = asyncHandler(async (req, res) => {
  const { name } = req.body;
  requireQuery(req.body, ['name']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.enableInterface(router, name);
  return success(res, data, `Interface ${name} diaktifkan`);
});

exports.disable = asyncHandler(async (req, res) => {
  const { name } = req.body;
  requireQuery(req.body, ['name']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.disableInterface(router, name);
  return success(res, data, `Interface ${name} dinonaktifkan`);
});
