'use strict';

const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/response');
const { requireFields } = require('../utils/validators');
const resolveRouter = require('../utils/resolveRouter');
const mikrotikService = require('../services/mikrotik.service');
const supabaseService = require('../services/supabase.service');

exports.addressList = asyncHandler(async (req, res) => {
  const router = await resolveRouter(req);
  const data = await mikrotikService.getAddressList(router, req.query.list);
  return success(res, data);
});

exports.addAddress = asyncHandler(async (req, res) => {
  requireFields(req.body, ['list', 'address']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.addAddressList(router, req.body);
  await supabaseService.logActivity({ action: 'firewall_address_add', router_id: router.id, target: req.body.address });
  return success(res, data, 'Address berhasil ditambahkan ke address-list', 201);
});

exports.removeAddress = asyncHandler(async (req, res) => {
  requireFields(req.body, ['list', 'address']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.removeAddressListByAddress(router, req.body.list, req.body.address);
  await supabaseService.logActivity({ action: 'firewall_address_remove', router_id: router.id, target: req.body.address });
  return success(res, data, 'Address berhasil dihapus dari address-list');
});
