'use strict';

const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/response');
const mikrotikService = require('../services/mikrotik.service');
const supabaseService = require('../services/supabase.service');
const { supabase } = require('../config/database');

exports.health = asyncHandler(async (req, res) => {
  let dbOk = true;
  try {
    const { error } = await supabase.from('routers').select('id').limit(1);
    if (error) dbOk = false;
  } catch (e) {
    dbOk = false;
  }

  return success(res, {
    status: 'ok',
    uptimeSeconds: process.uptime(),
    memoryUsageMb: Number((process.memoryUsage().rss / 1024 / 1024).toFixed(2)),
    supabase: dbOk ? 'connected' : 'unreachable',
    mikrotikPool: mikrotikService.status(),
    timestamp: new Date().toISOString()
  }, 'Backend berjalan normal');
});

exports.routerStatus = asyncHandler(async (req, res) => {
  const data = mikrotikService.status();
  return success(res, data);
});

exports.dashboard = asyncHandler(async (req, res) => {
  const routers = await supabaseService.getAllRouters(req.query);
  const customers = await supabaseService.getAllCustomers(req.query);

  const summary = {
    totalRouters: routers.length,
    totalCustomers: customers.length,
    activeCustomers: customers.filter((c) => c.status === 'active').length,
    isolirCustomers: customers.filter((c) => c.status === 'isolir').length,
    disabledCustomers: customers.filter((c) => c.status === 'disabled').length,
    byArea: routers.reduce((acc, r) => {
      acc[r.area || 'unknown'] = (acc[r.area || 'unknown'] || 0) + 1;
      return acc;
    }, {})
  };

  return success(res, summary);
});

exports.logs = asyncHandler(async (req, res) => {
  const data = await supabaseService.getLogs(req.query);
  return success(res, data);
});
