'use strict';

const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/response');
const { requireQuery } = require('../utils/validators');
const resolveRouter = require('../utils/resolveRouter');
const mikrotikService = require('../services/mikrotik.service');
const logger = require('../utils/logger');

exports.once = asyncHandler(async (req, res) => {
  requireQuery(req.query, ['interface']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.getTrafficOnce(router, req.query.interface);
  return success(res, data);
});

// Server-Sent Events untuk traffic realtime
exports.stream = asyncHandler(async (req, res) => {
  requireQuery(req.query, ['interface']);
  const router = await resolveRouter(req);

  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive'
  });
  res.flushHeaders();

  const heartbeat = setInterval(() => res.write(':\n\n'), 15000);

  let mtStream;
  try {
    mtStream = await mikrotikService.streamTraffic(
      router,
      req.query.interface,
      (data) => {
        res.write(`data: ${JSON.stringify(data)}\n\n`);
      },
      (err) => {
        logger.error(`Traffic stream error: ${err.message}`);
        res.write(`event: error\ndata: ${JSON.stringify({ message: err.message })}\n\n`);
      }
    );
  } catch (err) {
    clearInterval(heartbeat);
    res.write(`event: error\ndata: ${JSON.stringify({ message: err.message })}\n\n`);
    return res.end();
  }

  req.on('close', () => {
    clearInterval(heartbeat);
    try {
      mtStream && mtStream.close();
    } catch (e) {
      /* noop */
    }
  });
});

exports.torch = asyncHandler(async (req, res) => {
  requireQuery(req.query, ['interface']);
  const router = await resolveRouter(req);
  const duration = req.query.duration ? Number(req.query.duration) : 5000;
  const data = await mikrotikService.torch(router, req.query.interface, duration);
  return success(res, data);
});

exports.ping = asyncHandler(async (req, res) => {
  requireQuery(req.query, ['address']);
  const router = await resolveRouter(req);
  const count = req.query.count ? Number(req.query.count) : 4;
  const data = await mikrotikService.ping(router, req.query.address, count);
  return success(res, data);
});
