'use strict';

const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/response');
const { requireFields } = require('../utils/validators');
const resolveRouter = require('../utils/resolveRouter');
const mikrotikService = require('../services/mikrotik.service');
const supabaseService = require('../services/supabase.service');

exports.leases = asyncHandler(async (req, res) => {
  const router = await resolveRouter(req);
  const data = await mikrotikService.getDhcpLeases(router);
  return success(res, data);
});

exports.makeStatic = asyncHandler(async (req, res) => {
  requireFields(req.body, ['id']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.makeStaticDhcpLease(router, req.body.id);
  return success(res, data, 'Lease berhasil dijadikan static');
});

exports.removeLease = asyncHandler(async (req, res) => {
  requireFields(req.body, ['id']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.removeDhcpLease(router, req.body.id);
  await supabaseService.logActivity({ action: 'dhcp_lease_remove', router_id: router.id, target: req.body.id });
  return success(res, data, 'Lease berhasil dihapus');
});
