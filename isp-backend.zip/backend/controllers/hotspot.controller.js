'use strict';

const asyncHandler = require('../utils/asyncHandler');
const { success } = require('../utils/response');
const { requireFields } = require('../utils/validators');
const resolveRouter = require('../utils/resolveRouter');
const mikrotikService = require('../services/mikrotik.service');
const supabaseService = require('../services/supabase.service');

// ---------- HOTSPOT ACTIVE ----------
exports.active = asyncHandler(async (req, res) => {
  const router = await resolveRouter(req);
  const data = await mikrotikService.getHotspotActive(router);
  return success(res, data);
});

exports.disconnectActive = asyncHandler(async (req, res) => {
  requireFields(req.body, ['id']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.disconnectHotspotActive(router, req.body.id);
  return success(res, data, 'Sesi hotspot diputus');
});

// ---------- HOTSPOT USER ----------
exports.users = asyncHandler(async (req, res) => {
  const router = await resolveRouter(req);
  const data = await mikrotikService.getHotspotUsers(router);
  return success(res, data);
});

exports.userDetail = asyncHandler(async (req, res) => {
  requireFields(req.query, ['name']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.getHotspotUserByName(router, req.query.name);
  return success(res, data);
});

exports.createUser = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name', 'password']);
  const router = await resolveRouter(req);
  const { router_id, ...payload } = req.body;
  const data = await mikrotikService.createHotspotUser(router, payload);
  await supabaseService.logActivity({ action: 'hotspot_user_create', router_id: router.id, target: payload.name });
  return success(res, data, 'Hotspot user berhasil dibuat', 201);
});

exports.updateUser = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name']);
  const router = await resolveRouter(req);
  const { router_id, name, ...payload } = req.body;
  const data = await mikrotikService.updateHotspotUser(router, name, payload);
  return success(res, data, 'Hotspot user berhasil diupdate');
});

exports.deleteUser = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.deleteHotspotUser(router, req.body.name);
  await supabaseService.logActivity({ action: 'hotspot_user_delete', router_id: router.id, target: req.body.name });
  return success(res, data, 'Hotspot user berhasil dihapus');
});

// ---------- ENABLE / DISABLE ----------
exports.enable = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.enableCustomerHotspot(router, req.body.name);
  await supabaseService.logActivity({ action: 'hotspot_enable', router_id: router.id, target: req.body.name });
  return success(res, data, 'Pelanggan hotspot diaktifkan');
});

exports.disable = asyncHandler(async (req, res) => {
  requireFields(req.body, ['name']);
  const router = await resolveRouter(req);
  const data = await mikrotikService.disableCustomerHotspot(router, req.body.name);
  await supabaseService.logActivity({ action: 'hotspot_disable', router_id: router.id, target: req.body.name });
  return success(res, data, 'Pelanggan hotspot dinonaktifkan');
});
