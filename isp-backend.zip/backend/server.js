'use strict';

require('dotenv').config();

const app = require('./app');
const logger = require('./utils/logger');
const mikrotikService = require('./services/mikrotik.service');

const PORT = process.env.PORT || 4000;
const HOST = process.env.HOST || '0.0.0.0';

const server = app.listen(PORT, HOST, () => {
  logger.info(`ISP Backend berjalan di http://${HOST}:${PORT}${process.env.API_PREFIX || '/api/v1'}`);
});

function shutdown(signal) {
  logger.info(`Menerima sinyal ${signal}, mematikan server dengan aman...`);
  server.close(() => {
    logger.info('HTTP server ditutup.');
    mikrotikService.disconnectAll();
    process.exit(0);
  });

  setTimeout(() => {
    logger.error('Gagal shutdown dengan aman dalam batas waktu, force exit.');
    process.exit(1);
  }, 10000).unref();
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

process.on('unhandledRejection', (reason) => {
  logger.error(`Unhandled Rejection: ${reason && reason.stack ? reason.stack : reason}`);
});

process.on('uncaughtException', (err) => {
  logger.error(`Uncaught Exception: ${err.stack || err.message}`);
  process.exit(1);
});
