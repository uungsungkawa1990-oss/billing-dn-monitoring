'use strict';

const ApiError = require('./ApiError');
const supabaseService = require('../services/supabase.service');

/**
 * Ambil konfigurasi router dari Supabase berdasarkan router_id yang dikirim
 * lewat query, body, atau param. Wajib untuk semua endpoint multi-router.
 */
async function resolveRouter(req) {
  const routerId = req.query.router_id || req.body.router_id || req.params.router_id;
  if (!routerId) {
    throw new ApiError(422, 'Parameter router_id wajib dikirim (query/body/param)');
  }

  const row = await supabaseService.getRouterById(routerId);

  return {
    id: row.id,
    name: row.name,
    host: row.host || row.ip,
    port: row.port ? Number(row.port) : undefined,
    user: row.username || row.user,
    password: row.password,
    tls: row.use_tls || row.tls || false,
    area: row.area,
    hub: row.hub,
    type: row.type
  };
}

module.exports = resolveRouter;
