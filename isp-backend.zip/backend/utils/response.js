'use strict';

function success(res, data = null, message = 'OK', statusCode = 200, meta = undefined) {
  const payload = {
    success: true,
    message,
    data,
    timestamp: new Date().toISOString()
  };
  if (meta !== undefined) payload.meta = meta;
  return res.status(statusCode).json(payload);
}

function fail(res, message = 'Terjadi kesalahan', statusCode = 400, errors = null) {
  const payload = {
    success: false,
    message,
    errors,
    timestamp: new Date().toISOString()
  };
  return res.status(statusCode).json(payload);
}

module.exports = { success, fail };
