'use strict';

const ApiError = require('./ApiError');

function requireFields(obj, fields) {
  const missing = fields.filter((f) => obj[f] === undefined || obj[f] === null || obj[f] === '');
  if (missing.length) {
    throw new ApiError(422, `Field wajib diisi: ${missing.join(', ')}`);
  }
}

function requireQuery(query, fields) {
  const missing = fields.filter((f) => query[f] === undefined || query[f] === '');
  if (missing.length) {
    throw new ApiError(422, `Query param wajib: ${missing.join(', ')}`);
  }
}

function toBool(val, def = false) {
  if (val === undefined || val === null || val === '') return def;
  if (typeof val === 'boolean') return val;
  return ['1', 'true', 'yes', 'on'].includes(String(val).toLowerCase());
}

module.exports = { requireFields, requireQuery, toBool };
