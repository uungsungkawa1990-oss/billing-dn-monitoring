'use strict';

const { supabase, TABLES } = require('../config/database');
const ApiError = require('../utils/ApiError');
const logger = require('../utils/logger');

class SupabaseService {
  // ---------- ROUTERS (Multi Router / Multi Area / Multi Hub) ----------
  async getAllRouters(filters = {}) {
    let query = supabase.from(TABLES.ROUTERS).select('*');
    if (filters.area) query = query.eq('area', filters.area);
    if (filters.hub) query = query.eq('hub', filters.hub);
    if (filters.type) query = query.eq('type', filters.type);
    const { data, error } = await query;
    if (error) throw new ApiError(500, `Gagal ambil data router: ${error.message}`);
    return data;
  }

  async getRouterById(id) {
    const { data, error } = await supabase.from(TABLES.ROUTERS).select('*').eq('id', id).single();
    if (error) throw new ApiError(404, `Router dengan id ${id} tidak ditemukan: ${error.message}`);
    return data;
  }

  async createRouter(payload) {
    const { data, error } = await supabase.from(TABLES.ROUTERS).insert(payload).select().single();
    if (error) throw new ApiError(400, `Gagal menambah router: ${error.message}`);
    return data;
  }

  async updateRouter(id, payload) {
    const { data, error } = await supabase.from(TABLES.ROUTERS).update(payload).eq('id', id).select().single();
    if (error) throw new ApiError(400, `Gagal update router: ${error.message}`);
    return data;
  }

  async deleteRouter(id) {
    const { error } = await supabase.from(TABLES.ROUTERS).delete().eq('id', id);
    if (error) throw new ApiError(400, `Gagal hapus router: ${error.message}`);
    return { deleted: true };
  }

  // ---------- CUSTOMERS ----------
  async getAllCustomers(filters = {}) {
    let query = supabase.from(TABLES.CUSTOMERS).select('*');
    if (filters.area) query = query.eq('area', filters.area);
    if (filters.router_id) query = query.eq('router_id', filters.router_id);
    if (filters.status) query = query.eq('status', filters.status);
    if (filters.connection_type) query = query.eq('connection_type', filters.connection_type);
    const { data, error } = await query;
    if (error) throw new ApiError(500, `Gagal ambil data pelanggan: ${error.message}`);
    return data;
  }

  async getCustomerById(id) {
    const { data, error } = await supabase.from(TABLES.CUSTOMERS).select('*').eq('id', id).single();
    if (error) throw new ApiError(404, `Pelanggan dengan id ${id} tidak ditemukan: ${error.message}`);
    return data;
  }

  async getCustomerByUsername(username) {
    const { data, error } = await supabase.from(TABLES.CUSTOMERS).select('*').eq('username', username).maybeSingle();
    if (error) throw new ApiError(500, `Gagal ambil data pelanggan: ${error.message}`);
    return data;
  }

  async createCustomer(payload) {
    const { data, error } = await supabase.from(TABLES.CUSTOMERS).insert(payload).select().single();
    if (error) throw new ApiError(400, `Gagal menambah pelanggan: ${error.message}`);
    return data;
  }

  async updateCustomer(id, payload) {
    const { data, error } = await supabase.from(TABLES.CUSTOMERS).update(payload).eq('id', id).select().single();
    if (error) throw new ApiError(400, `Gagal update pelanggan: ${error.message}`);
    return data;
  }

  async updateCustomerStatus(id, status) {
    return this.updateCustomer(id, { status, updated_at: new Date().toISOString() });
  }

  async deleteCustomer(id) {
    const { error } = await supabase.from(TABLES.CUSTOMERS).delete().eq('id', id);
    if (error) throw new ApiError(400, `Gagal hapus pelanggan: ${error.message}`);
    return { deleted: true };
  }

  // ---------- NETWORK NODES (Hybrid: MikroTik->Hub->Hub->Pelanggan & OLT->ODC->ODP->ONT) ----------
  async getAllNodes(filters = {}) {
    let query = supabase.from(TABLES.NETWORK_NODES).select('*');
    if (filters.type) query = query.eq('type', filters.type);
    if (filters.parent_id) query = query.eq('parent_id', filters.parent_id);
    if (filters.area) query = query.eq('area', filters.area);
    const { data, error } = await query;
    if (error) throw new ApiError(500, `Gagal ambil data topologi jaringan: ${error.message}`);
    return data;
  }

  async getNodeById(id) {
    const { data, error } = await supabase.from(TABLES.NETWORK_NODES).select('*').eq('id', id).single();
    if (error) throw new ApiError(404, `Node ${id} tidak ditemukan: ${error.message}`);
    return data;
  }

  async createNode(payload) {
    const { data, error } = await supabase.from(TABLES.NETWORK_NODES).insert(payload).select().single();
    if (error) throw new ApiError(400, `Gagal menambah node: ${error.message}`);
    return data;
  }

  async updateNode(id, payload) {
    const { data, error } = await supabase.from(TABLES.NETWORK_NODES).update(payload).eq('id', id).select().single();
    if (error) throw new ApiError(400, `Gagal update node: ${error.message}`);
    return data;
  }

  async deleteNode(id) {
    const { error } = await supabase.from(TABLES.NETWORK_NODES).delete().eq('id', id);
    if (error) throw new ApiError(400, `Gagal hapus node: ${error.message}`);
    return { deleted: true };
  }

  /**
   * Bangun pohon topologi hybrid secara rekursif dari root node.
   * Mendukung: MikroTik -> Hub -> Hub -> Pelanggan
   * dan: OLT -> ODC -> ODP -> ONT
   */
  async buildTopologyTree(rootId = null) {
    const { data: allNodes, error } = await supabase.from(TABLES.NETWORK_NODES).select('*');
    if (error) throw new ApiError(500, `Gagal ambil topologi: ${error.message}`);

    const byParent = new Map();
    for (const node of allNodes) {
      const pid = node.parent_id || 'root';
      if (!byParent.has(pid)) byParent.set(pid, []);
      byParent.get(pid).push(node);
    }

    const build = (parentId) => {
      const children = byParent.get(parentId) || [];
      return children.map((child) => ({
        ...child,
        children: build(child.id)
      }));
    };

    if (rootId) {
      const root = allNodes.find((n) => n.id === rootId);
      if (!root) throw new ApiError(404, `Root node ${rootId} tidak ditemukan`);
      return { ...root, children: build(root.id) };
    }

    return build('root');
  }

  // ---------- ACTIVITY LOG ----------
  async logActivity({ action, actor, target, router_id, meta }) {
    try {
      const { error } = await supabase.from(TABLES.LOGS).insert({
        action,
        actor: actor || 'system',
        target: target || null,
        router_id: router_id || null,
        meta: meta || null,
        created_at: new Date().toISOString()
      });
      if (error) logger.warn(`Gagal simpan activity log: ${error.message}`);
    } catch (err) {
      logger.warn(`Gagal simpan activity log: ${err.message}`);
    }
  }

  async getLogs(filters = {}) {
    let query = supabase.from(TABLES.LOGS).select('*').order('created_at', { ascending: false });
    if (filters.limit) query = query.limit(Number(filters.limit));
    if (filters.router_id) query = query.eq('router_id', filters.router_id);
    if (filters.action) query = query.eq('action', filters.action);
    const { data, error } = await query;
    if (error) throw new ApiError(500, `Gagal ambil log: ${error.message}`);
    return data;
  }
}

module.exports = new SupabaseService();
