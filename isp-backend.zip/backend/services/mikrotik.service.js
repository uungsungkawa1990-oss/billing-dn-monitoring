'use strict';

const { RouterOSAPI } = require('node-routeros');
const logger = require('../utils/logger');
const ApiError = require('../utils/ApiError');
const mtConfig = require('../config/mikrotik');

/**
 * Connection pool per router (multi-router / multi-area / multi-hub).
 * key = router.id (string/uuid dari Supabase) atau composite host:port
 */
class MikrotikManager {
  constructor() {
    this.pool = new Map();
  }

  _key(router) {
    return String(router.id || `${router.host}:${router.port}`);
  }

  /**
   * Ambil koneksi aktif, buat baru jika belum ada / terputus.
   * router: { id, host, port, user, password, tls }
   */
  async getConnection(router) {
    if (!router || !router.host || !router.user) {
      throw new ApiError(422, 'Konfigurasi router tidak lengkap (host/user wajib)');
    }

    const key = this._key(router);
    let entry = this.pool.get(key);

    if (entry && entry.api && entry.api.connected) {
      return entry.api;
    }

    if (entry && entry.connecting) {
      // tunggu proses connect yang sedang berjalan
      await entry.connecting;
      if (entry.api && entry.api.connected) return entry.api;
    }

    return this._connect(router, key);
  }

  async _connect(router, key) {
    const useTls = router.tls !== undefined ? !!router.tls : mtConfig.useTls;
    const port = router.port || (useTls ? mtConfig.defaultTlsPort : mtConfig.defaultPort);

    const api = new RouterOSAPI({
      host: router.host,
      user: router.user,
      password: router.password,
      port,
      tls: useTls ? {} : undefined,
      timeout: mtConfig.timeout,
      keepalive: true
    });

    const entry = {
      api,
      router,
      connected: false,
      reconnectAttempts: 0,
      connecting: null
    };
    this.pool.set(key, entry);

    const connectPromise = (async () => {
      try {
        await api.connect();
        entry.connected = true;
        entry.reconnectAttempts = 0;
        logger.info(`MikroTik terkoneksi: ${router.name || router.host} (${router.host}:${port})`);

        api.on('close', () => {
          entry.connected = false;
          logger.warn(`MikroTik koneksi terputus: ${router.name || router.host}`);
          this._scheduleReconnect(key);
        });
        api.on('error', (err) => {
          entry.connected = false;
          logger.error(`MikroTik error [${router.name || router.host}]: ${err.message}`);
        });

        return api;
      } catch (err) {
        entry.connected = false;
        logger.error(`Gagal konek MikroTik ${router.host}:${port} -> ${err.message}`);
        this._scheduleReconnect(key);
        throw new ApiError(503, `Gagal terhubung ke MikroTik ${router.host}: ${err.message}`);
      } finally {
        entry.connecting = null;
      }
    })();

    entry.connecting = connectPromise;
    return connectPromise;
  }

  _scheduleReconnect(key) {
    const entry = this.pool.get(key);
    if (!entry) return;

    const max = mtConfig.maxReconnectAttempts;
    if (max > 0 && entry.reconnectAttempts >= max) {
      logger.error(`Batas reconnect tercapai untuk router ${entry.router.host}, berhenti mencoba.`);
      return;
    }

    entry.reconnectAttempts += 1;
    setTimeout(() => {
      logger.info(`Mencoba reconnect ke ${entry.router.host} (percobaan ke-${entry.reconnectAttempts})`);
      this._connect(entry.router, key).catch(() => {});
    }, mtConfig.reconnectInterval);
  }

  async testLogin(router) {
    const api = await this.getConnection(router);
    const identity = await api.write('/system/identity/print');
    return { connected: true, identity: identity[0] || null };
  }

  disconnect(routerId) {
    const entry = [...this.pool.values()].find((e) => this._key(e.router) === String(routerId));
    if (entry && entry.api) {
      entry.api.close();
      this.pool.delete(this._key(entry.router));
    }
  }

  disconnectAll() {
    for (const entry of this.pool.values()) {
      try {
        entry.api.close();
      } catch (e) {
        /* noop */
      }
    }
    this.pool.clear();
  }

  status() {
    return [...this.pool.entries()].map(([key, entry]) => ({
      key,
      host: entry.router.host,
      name: entry.router.name,
      connected: !!entry.connected,
      reconnectAttempts: entry.reconnectAttempts
    }));
  }

  // ---------- generic exec ----------
  async exec(router, command, params = []) {
    const api = await this.getConnection(router);
    return api.write(command, params);
  }

  // ---------- SYSTEM RESOURCE ----------
  async getResourceCpu(router) {
    const [res] = await this.exec(router, '/system/resource/print');
    return {
      cpuLoad: Number(res['cpu-load']),
      cpuCount: Number(res['cpu-count']),
      cpuFrequency: res['cpu-frequency'],
      architecture: res['architecture-name'],
      board: res['board-name'],
      version: res.version,
      uptime: res.uptime
    };
  }

  async getResourceMemory(router) {
    const [res] = await this.exec(router, '/system/resource/print');
    const total = Number(res['total-memory']);
    const free = Number(res['free-memory']);
    return {
      totalMemory: total,
      freeMemory: free,
      usedMemory: total - free,
      usedPercent: total ? Number((((total - free) / total) * 100).toFixed(2)) : 0
    };
  }

  async getResourceDisk(router) {
    const [res] = await this.exec(router, '/system/resource/print');
    const total = Number(res['total-hdd-space']);
    const free = Number(res['free-hdd-space']);
    return {
      totalHdd: total,
      freeHdd: free,
      usedHdd: total - free,
      usedPercent: total ? Number((((total - free) / total) * 100).toFixed(2)) : 0
    };
  }

  async getResourceAll(router) {
    const [res] = await this.exec(router, '/system/resource/print');
    return res;
  }

  async getIdentity(router) {
    const [res] = await this.exec(router, '/system/identity/print');
    return res;
  }

  async reboot(router) {
    await this.exec(router, '/system/reboot');
    return { rebooted: true };
  }

  // ---------- INTERFACE ----------
  async getInterfaces(router) {
    return this.exec(router, '/interface/print');
  }

  async getInterfaceByName(router, name) {
    return this.exec(router, '/interface/print', [`?name=${name}`]);
  }

  async enableInterface(router, name) {
    const [iface] = await this.getInterfaceByName(router, name);
    if (!iface) throw new ApiError(404, `Interface ${name} tidak ditemukan`);
    return this.exec(router, '/interface/enable', [`=.id=${iface['.id']}`]);
  }

  async disableInterface(router, name) {
    const [iface] = await this.getInterfaceByName(router, name);
    if (!iface) throw new ApiError(404, `Interface ${name} tidak ditemukan`);
    return this.exec(router, '/interface/disable', [`=.id=${iface['.id']}`]);
  }

  // ---------- TRAFFIC REALTIME ----------
  async getTrafficOnce(router, interfaceName) {
    const api = await this.getConnection(router);
    return new Promise((resolve, reject) => {
      const stream = api.stream('/interface/monitor-traffic', [`=interface=${interfaceName}`, '=once='], (err, data) => {
        if (err) return reject(err);
        if (data) {
          stream.close();
          resolve(data[0] || data);
        }
      });
    });
  }

  streamTraffic(router, interfaceName, onData, onError) {
    // caller harus menyimpan reference untuk stop()
    return this.getConnection(router).then((api) => {
      const stream = api.stream('/interface/monitor-traffic', [`=interface=${interfaceName}`], (err, data) => {
        if (err) {
          if (onError) onError(err);
          return;
        }
        if (data) onData(data);
      });
      return stream;
    });
  }

  // ---------- PPPoE ACTIVE ----------
  async getPppoeActive(router) {
    return this.exec(router, '/ppp/active/print');
  }

  async disconnectPppoeActive(router, id) {
    return this.exec(router, '/ppp/active/remove', [`=.id=${id}`]);
  }

  // ---------- PPP SECRET ----------
  async getPppSecrets(router, filters = []) {
    return this.exec(router, '/ppp/secret/print', filters);
  }

  async getPppSecretByName(router, name) {
    const res = await this.exec(router, '/ppp/secret/print', [`?name=${name}`]);
    return res[0] || null;
  }

  async createPppSecret(router, data) {
    const params = Object.entries(data).map(([k, v]) => `=${k}=${v}`);
    return this.exec(router, '/ppp/secret/add', params);
  }

  async updatePppSecret(router, name, data) {
    const secret = await this.getPppSecretByName(router, name);
    if (!secret) throw new ApiError(404, `PPP secret ${name} tidak ditemukan`);
    const params = [`=.id=${secret['.id']}`, ...Object.entries(data).map(([k, v]) => `=${k}=${v}`)];
    return this.exec(router, '/ppp/secret/set', params);
  }

  async deletePppSecret(router, name) {
    const secret = await this.getPppSecretByName(router, name);
    if (!secret) throw new ApiError(404, `PPP secret ${name} tidak ditemukan`);
    return this.exec(router, '/ppp/secret/remove', [`=.id=${secret['.id']}`]);
  }

  async setPppSecretDisabled(router, name, disabled) {
    return this.updatePppSecret(router, name, { disabled: disabled ? 'yes' : 'no' });
  }

  // ---------- HOTSPOT ACTIVE ----------
  async getHotspotActive(router) {
    return this.exec(router, '/ip/hotspot/active/print');
  }

  async disconnectHotspotActive(router, id) {
    return this.exec(router, '/ip/hotspot/active/remove', [`=.id=${id}`]);
  }

  // ---------- HOTSPOT USER ----------
  async getHotspotUsers(router, filters = []) {
    return this.exec(router, '/ip/hotspot/user/print', filters);
  }

  async getHotspotUserByName(router, name) {
    const res = await this.exec(router, '/ip/hotspot/user/print', [`?name=${name}`]);
    return res[0] || null;
  }

  async createHotspotUser(router, data) {
    const params = Object.entries(data).map(([k, v]) => `=${k}=${v}`);
    return this.exec(router, '/ip/hotspot/user/add', params);
  }

  async updateHotspotUser(router, name, data) {
    const user = await this.getHotspotUserByName(router, name);
    if (!user) throw new ApiError(404, `Hotspot user ${name} tidak ditemukan`);
    const params = [`=.id=${user['.id']}`, ...Object.entries(data).map(([k, v]) => `=${k}=${v}`)];
    return this.exec(router, '/ip/hotspot/user/set', params);
  }

  async deleteHotspotUser(router, name) {
    const user = await this.getHotspotUserByName(router, name);
    if (!user) throw new ApiError(404, `Hotspot user ${name} tidak ditemukan`);
    return this.exec(router, '/ip/hotspot/user/remove', [`=.id=${user['.id']}`]);
  }

  async setHotspotUserDisabled(router, name, disabled) {
    return this.updateHotspotUser(router, name, { disabled: disabled ? 'yes' : 'no' });
  }

  // ---------- QUEUE SIMPLE ----------
  async getQueueSimple(router, filters = []) {
    return this.exec(router, '/queue/simple/print', filters);
  }

  async getQueueSimpleByName(router, name) {
    const res = await this.exec(router, '/queue/simple/print', [`?name=${name}`]);
    return res[0] || null;
  }

  async createQueueSimple(router, data) {
    const params = Object.entries(data).map(([k, v]) => `=${k}=${v}`);
    return this.exec(router, '/queue/simple/add', params);
  }

  async updateQueueSimple(router, name, data) {
    const q = await this.getQueueSimpleByName(router, name);
    if (!q) throw new ApiError(404, `Queue simple ${name} tidak ditemukan`);
    const params = [`=.id=${q['.id']}`, ...Object.entries(data).map(([k, v]) => `=${k}=${v}`)];
    return this.exec(router, '/queue/simple/set', params);
  }

  async deleteQueueSimple(router, name) {
    const q = await this.getQueueSimpleByName(router, name);
    if (!q) throw new ApiError(404, `Queue simple ${name} tidak ditemukan`);
    return this.exec(router, '/queue/simple/remove', [`=.id=${q['.id']}`]);
  }

  async setQueueSimpleDisabled(router, name, disabled) {
    return this.updateQueueSimple(router, name, { disabled: disabled ? 'yes' : 'no' });
  }

  // ---------- QUEUE TREE ----------
  async getQueueTree(router, filters = []) {
    return this.exec(router, '/queue/tree/print', filters);
  }

  async createQueueTree(router, data) {
    const params = Object.entries(data).map(([k, v]) => `=${k}=${v}`);
    return this.exec(router, '/queue/tree/add', params);
  }

  async updateQueueTree(router, id, data) {
    const params = [`=.id=${id}`, ...Object.entries(data).map(([k, v]) => `=${k}=${v}`)];
    return this.exec(router, '/queue/tree/set', params);
  }

  async deleteQueueTree(router, id) {
    return this.exec(router, '/queue/tree/remove', [`=.id=${id}`]);
  }

  // ---------- FIREWALL ADDRESS LIST ----------
  async getAddressList(router, listName) {
    const filters = listName ? [`?list=${listName}`] : [];
    return this.exec(router, '/ip/firewall/address-list/print', filters);
  }

  async addAddressList(router, { list, address, comment, timeout }) {
    const params = [`=list=${list}`, `=address=${address}`];
    if (comment) params.push(`=comment=${comment}`);
    if (timeout) params.push(`=timeout=${timeout}`);
    return this.exec(router, '/ip/firewall/address-list/add', params);
  }

  async removeAddressListByAddress(router, list, address) {
    const found = await this.exec(router, '/ip/firewall/address-list/print', [`?list=${list}`, `?address=${address}`]);
    if (!found.length) return { removed: 0 };
    for (const item of found) {
      await this.exec(router, '/ip/firewall/address-list/remove', [`=.id=${item['.id']}`]);
    }
    return { removed: found.length };
  }

  // ---------- DHCP LEASE ----------
  async getDhcpLeases(router, filters = []) {
    return this.exec(router, '/ip/dhcp-server/lease/print', filters);
  }

  async makeStaticDhcpLease(router, id) {
    return this.exec(router, '/ip/dhcp-server/lease/make-static', [`=.id=${id}`]);
  }

  async removeDhcpLease(router, id) {
    return this.exec(router, '/ip/dhcp-server/lease/remove', [`=.id=${id}`]);
  }

  // ---------- PING ----------
  async ping(router, address, count = 4) {
    const api = await this.getConnection(router);
    return new Promise((resolve, reject) => {
      const results = [];
      const stream = api.stream('/ping', [`=address=${address}`, `=count=${count}`], (err, data) => {
        if (err) {
          stream.close();
          return reject(err);
        }
        if (data) {
          results.push(...data);
        }
      });
      setTimeout(() => {
        try {
          stream.close();
        } catch (e) {
          /* noop */
        }
        resolve(results);
      }, Math.max(count * 1200, 3000));
    });
  }

  // ---------- TORCH ----------
  async torch(router, interfaceName, durationMs = 5000) {
    const api = await this.getConnection(router);
    return new Promise((resolve, reject) => {
      const results = [];
      const stream = api.stream('/tool/torch', [`=interface=${interfaceName}`], (err, data) => {
        if (err) {
          stream.close();
          return reject(err);
        }
        if (data) results.push(...data);
      });
      setTimeout(() => {
        try {
          stream.close();
        } catch (e) {
          /* noop */
        }
        resolve(results);
      }, durationMs);
    });
  }

  // ---------- CUSTOMER STATE MANAGEMENT (PPPoE & Hotspot) ----------
  async enableCustomerPppoe(router, name) {
    await this.setPppSecretDisabled(router, name, false);
    await this.removeAddressListByAddress(router, mtConfig.isolirAddressList, name).catch(() => {});
    return { name, status: 'enabled' };
  }

  async disableCustomerPppoe(router, name) {
    await this.setPppSecretDisabled(router, name, true);
    const active = await this.exec(router, '/ppp/active/print', [`?name=${name}`]);
    for (const a of active) {
      await this.disconnectPppoeActive(router, a['.id']);
    }
    return { name, status: 'disabled' };
  }

  async isolirCustomerPppoe(router, name) {
    const secret = await this.getPppSecretByName(router, name);
    if (!secret) throw new ApiError(404, `PPP secret ${name} tidak ditemukan`);
    await this.updatePppSecret(router, name, { profile: mtConfig.isolirProfile });
    const active = await this.exec(router, '/ppp/active/print', [`?name=${name}`]);
    for (const a of active) {
      await this.disconnectPppoeActive(router, a['.id']);
    }
    return { name, status: 'isolir' };
  }

  async activateCustomerPppoe(router, name, originalProfile) {
    await this.updatePppSecret(router, name, {
      profile: originalProfile || 'default',
      disabled: 'no'
    });
    return { name, status: 'active' };
  }

  async enableCustomerHotspot(router, name) {
    await this.setHotspotUserDisabled(router, name, false);
    return { name, status: 'enabled' };
  }

  async disableCustomerHotspot(router, name) {
    await this.setHotspotUserDisabled(router, name, true);
    const active = await this.exec(router, '/ip/hotspot/active/print', [`?user=${name}`]);
    for (const a of active) {
      await this.disconnectHotspotActive(router, a['.id']);
    }
    return { name, status: 'disabled' };
  }

  async isolirCustomerQueue(router, queueName) {
    await this.updateQueueSimple(router, queueName, {
      'max-limit': mtConfig.isolirQueueMaxLimit
    });
    return { name: queueName, status: 'isolir', limit: mtConfig.isolirQueueMaxLimit };
  }

  async activateCustomerQueue(router, queueName, originalMaxLimit) {
    await this.updateQueueSimple(router, queueName, {
      'max-limit': originalMaxLimit || '0/0'
    });
    return { name: queueName, status: 'active' };
  }
}

module.exports = new MikrotikManager();
